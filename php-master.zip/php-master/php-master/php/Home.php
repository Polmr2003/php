<?php
// importamos las classes con las funciones
require_once 'Funtions.php';

myMenu();

?>

<!-- ------------------------------------------------- HTML ----------------------------------------------------------------------- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pizza planet</title>
    <link rel="stylesheet" type="text/css" href="../css/estilo.css" />
</head>

<body>

    <img src="../images/pizza3.png" width="650px" height="500px" style="float:right;">
    <h2>Pizza planet</h2>
    <h3>Un planeta lleno de sabor</h3>
    <button class="my_BtnHome">
            <p class="txt_my_BtnHome">Ordenar ahora</p>
    </button>


</body>

</html>